#ifndef __FMQ_H__
#define __FMQ_H__

#include "stm32f10x.h"  

int FMQ_Init(void);
int FMQ_ON(void);
int FMQ_OFF(void);

#endif

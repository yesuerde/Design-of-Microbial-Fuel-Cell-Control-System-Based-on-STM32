#ifndef __MOTOR_H__
#define __MOTOR_H__

void Motor_Init(void);

void Motor_ON(void);
void Motor_OFF(void);


#endif

#ifndef __PWM_H__
#define __PWM_H__

#include "stm32f10x.h" 

void Timer_Init(uint16_t total,uint16_t duty);

#endif

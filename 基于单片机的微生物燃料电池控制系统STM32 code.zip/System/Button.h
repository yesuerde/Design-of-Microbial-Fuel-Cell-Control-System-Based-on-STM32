#ifndef __BUTTON_H__
#define __BUTTON_H__

#include "stm32f10x.h"  

void Button_Init(void);
uint8_t Button_up(void);
uint8_t Button_down(void);

#endif

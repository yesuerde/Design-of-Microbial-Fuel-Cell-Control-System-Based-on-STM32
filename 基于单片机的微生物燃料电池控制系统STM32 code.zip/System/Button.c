#include "stm32f10x.h"                  // Device header
#include "Delay.h"

void Button_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE );
	
	GPIO_InitStructure.GPIO_Mode =GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin =GPIO_Pin_1|GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Speed =GPIO_Speed_50MHz;
	
	GPIO_Init(GPIOA ,&GPIO_InitStructure);
}


uint8_t Button_up(void)					//��������KeyUp=1
{
	uint8_t KeyUp=0;
	if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1) == 0)
	{
		Delay_ms(20);
		while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1) == 0);
		Delay_ms(20);
		KeyUp= 1;
	}
	else
	{
		KeyUp=0;
	}
	return KeyUp;
}

uint8_t Button_down(void)					//��������KeyDown=1
{
	uint8_t KeyDown=0;
	if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_2) == 0)
	{
		Delay_ms(20);
		while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_2) == 0);
		Delay_ms(20);
		KeyDown = 1;
	}
	else
	{
		KeyDown=0;
	}
	return KeyDown;
}
